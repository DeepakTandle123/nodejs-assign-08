const express = require("express");
const bodyParser =require("body-parser");
const app = express();
const userRoute = require("./routes/user")
const mongoose = require("mongoose");
const postRoute = require("./routes/post");
const uploadRoute = require("./routes/upload");


app.use(bodyParser.json())
mongoose.connect("mongodb+srv://mehulmk9179:SQAGTBcrOXh8J5XW@cluster0.pbylivg.mongodb.net/assignment_8?retryWrites=true&w=majority").then(
    res=>{
        console.log("Connected to DB")
    }
).catch(err=>{
    console.log("Connection failed");
})

app.use("/user",userRoute);
app.use("/post",postRoute);
app.use("/upload",uploadRoute)
app.listen(3000);