const express = require("express");
const multer = require("multer");
const uploadRoute = express.Router();
const upload = multer({dest:"uploads/"});

uploadRoute.post("/pic",upload.single("image"),(req,res)=>{
    res.status(200).json({
        message: "File uploaded SuccessFully!!"
    })
})

module.exports = uploadRoute;