const express = require("express");
const Post = require("../model/post");
const authMiddleWare = require("../middleware/authMiddleWare");
const postRoute = express.Router();

postRoute.get("/posts",authMiddleWare,(req,res)=>{
    Post.find().then(response=>{
        res.status(200).json({
            message: "Posts fetched Successfully",
            result: response
        })
    }).catch(err=>{
        res.status(400).json({
            message : "Posts unavailable",
            errDesc : err
        })
    })
})


postRoute.post("/posts",authMiddleWare,(req,res)=>{
    const postData = req.body;
    const posts = new Post({
        title : postData.title,
        body : postData.body,
        image: postData.image,
        user: req.id
    })
    posts.save().then(result=>{
        res.status(200).json({
            message : "Post created Successfully!!",
            data : result
        })
    }).catch(err=>{
        res.status(400).json({
            message : "Post not Created",
            errdesc :err
        })
    })
})

postRoute.put("/posts/:id",authMiddleWare,(req,res)=>{
    const id = req.params.id;
    const updatedContent = req.body;
    if(id){
        Post.findOneAndUpdate({
            _id : id,
            userId : req.userId
        },updatedContent).then(result=>{
            if(!result){
                res.status(400).json({
                    message : "Permission Denied",
                })
            }else{
                res.status(200).json({
                    message: "Post updated Successfully",
                    data : result
                })
            }
        }).catch(err=>{
            res.status(500).json({
                message:"Something Went Wrong",
                errDesc : err
            })
        })
    }else{
        res.status(400).json({
            message : "Wrong infos are Given"
        })
    }
})

postRoute.delete("/posts/:id",authMiddleWare,(req,res)=>{
    const id= req.params.id;
    if(id){
        Post.deleteOne({_id:id,userId:req.userid}).then(response=>{
            if(response.deletedCount){
                res.status(200).json({
                    message: "Post deleted Successfully",
                    deleteddata : response
                })
            }else{
                res.status(400).json({
                    message: "Post not found"
                })
            }
        }).catch(err=>{
            res.status(500).json({
                message:"Something Went Wrong!!",
                errDesc : err
            })
        })
    }
})
module.exports= postRoute;