const express= require("express");
const User = require("../model/user");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken")
const userRoute = express.Router();

userRoute.post("/register",(req,res)=>{
    const {name,email,password}= req.body;
    bcrypt.hash(password,10).then(hasPass=>{
        const user = new User({
            name,
            email,
            password : hasPass
        })
        user.save().then(response=>{
            res.status(200).json({
                message : "User registered Successfully",
                data : response
            })
        }).catch(err=>{
            res.status(400).json({
                message : "Email already exist",
                errDesc : err
            })
        })
    }).catch(err=>{
        res.status(400).json({
            message : "User not registered",
            errDesc : err
        })
    })
})

userRoute.post("/login",(req,res)=>{
    const loginData = req.body;

    User.findOne({email:loginData.email}).then(user=>{
        if(user){
            bcrypt.compare(loginData.password,user.password).then(authStatus=>{
             if(authStatus){
                const jwtToken = jwt.sign(
                    {
                        email : user.email,
                        name:user.name,
                        id: user._id
                    },
                    "Assignment8",
                    {
                        expiresIn: "1h"
                    }
                )
                res.status(200).json({
                        message:"Login SuccessFull",
                        token : jwtToken
                })
             }else{
                    res.status(400).json({
                        message:"Email or password does not match"
                    })
             }
            })
        }else{
            res.status(400).json({
                message: "Email is not registered"
            })
        }
    }).catch(err=>{
        res.status(400).json({
            message: "Something went Wrong",
            errDesc : err
        })
    })
})

module.exports = userRoute;