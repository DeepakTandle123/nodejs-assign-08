
const jwt = require("jsonwebtoken");



module.exports = (req,res,next)=>{
    try{
    const token = req.headers.authorization.split(" ")[1];
    const auth = jwt.verify(token,"Assignment8");
    req.id= auth.id;
    next();
    }catch(err){
        res.status(400).json({
            message : "Authentication Failed",
            errDesc : err
        })
    }
}